// window.addEventListener('DOMContentLoaded', function(){
// });

var tile = document.querySelectorAll('li');

for (var i = 0; i<tile.length; i++)
  tile[i].addEventListener("click", function() {
      var getSound = this.id + ".wav";
      console.log(getSound);
      //src = getSound;
      getSound.play();

});



// var getSound = [ ];
// getSound.push(this.id);
// console.log(getSound);
  // console.log(this.id);

// switch(this.id) {
//     case after:
//     after.src = "https://upload.wikimedia.org/wikipedia/commons/e/ef/Eastern_Whipbird.ogg";
//     after.play();
//     console.log(this.id);
//         break;
//     case 1:
//         console.log(tile[1]);
//         break;
//     default:
//         console.log(tile[3]);
// }
//
// var noiseMaker = document.getElementById("after");
//
//
//
//   var playButton = document.getElementById("after");
//
//   playButton.addEventListener('click', function(){
//     noiseMaker.src = "";
//     noiseMaker.play();

//});
