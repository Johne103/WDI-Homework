// window.addEventListener('DOMContentLoaded', function(){
// });

var tile = document.querySelectorAll('li');

for (var i = 0; i<tile.length; i++)
  tile[i].addEventListener("click", function() {
      this.textContent = this.id;
      var getSound = "sounds/" + this.id + ".wav";
      console.log(getSound);
      //li.src = getSound;
    //noiseMaker.play();
      //src = getSound;
      //getSound.play();

});
