
var tile = document.querySelectorAll('li');

for (var i = 0; i<tile.length; i++)
  tile[i].addEventListener("click", function() {
      //this.textContent = "X";
      //console.log();
});
 var getSound = tile[i];

// switch(getSound {
//     case 0:
//         console.log(tile[0]);
//         break;
//     case 1:
//         console.log(tile[1]);
//         break;
//     default:
//         console.log(tile[3]);
// }
//
// var noiseMaker = document.getElementById("after");
//
//
//
//   var playButton = document.getElementById("after");
//
//   playButton.addEventListener('click', function(){
//     noiseMaker.src = "";
//     noiseMaker.play();

//});
